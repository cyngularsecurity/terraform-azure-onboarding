import logging
import traceback
import os
import time
from functools import wraps

from azure.mgmt.subscription import SubscriptionClient
from azure.identity import ManagedIdentityCredential
from azure.mgmt.monitor.models import DiagnosticSettingsResource

import ds_settings as cyngular_ds

client_id = os.environ["UAI_ID"]

def get_client_credentials() -> ManagedIdentityCredential:
    try:
        return ManagedIdentityCredential(
            client_id=client_id
        )
    except Exception:
        logging.critical(traceback.format_exc())
        raise Exception("Error getting Client Credentials")

def get_subscriptions(credentials):
    try:
        subscription_client = SubscriptionClient(credentials)
        sub_list_o = subscription_client.subscriptions.list()

        sub_list = []
        for subscription in sub_list_o:
            sub_list.append({
                'subscription_id': subscription.subscription_id,
                'subscription_name': subscription.display_name
            })
        return sub_list
    except Exception:
        logging.critical(traceback.format_exc())
        raise Exception("Error when trying to get subscriptions id list")


def create_diagnostic_settings(monitor_client, resource_id, storage_account_id, categories, cyngular_ds_name, company_name):
    try:
        logs = [
            {"category": category, "enabled": True} if not is_category_group else {"categoryGroup": category, "enabled": True}
            for category, is_category_group in categories.items()
        ]

        existing_settings = monitor_client.diagnostic_settings.list(
            resource_uri=resource_id
        )
        setting_name = next((setting.name for setting in existing_settings if setting.storage_account_id == storage_account_id), None)

        parameters = DiagnosticSettingsResource(
            storage_account_id=storage_account_id,
            logs=logs
        )

        monitor_client.diagnostic_settings.create_or_update(
            resource_uri=resource_id,
            name=setting_name or f"{cyngular_ds_name}-{company_name}",
            parameters=parameters
        )
    except Exception:
        logging.critical(traceback.format_exc())


def find_network_watcher(network_client, location):
    try:
        network_watchers = network_client.network_watchers.list_all()
        for nw in network_watchers:
            if nw.location.lower() == location.lower():
                return nw
        return None
    except Exception:
        logging.critical(traceback.format_exc())
        raise Exception("Error getting Network Watcher")


def process_resource_for_ds(resource, monitor_client, sa_map, company_name, enable_audit_events_logs, enable_aks_logs, all_logs_types, all_logs_and_audit_types, subscription_id=None):
    try:
        resource_name, resource_id = resource['name'], resource['id']
        resource_type, resource_location = resource['type'].lower(), resource['location']

        if resource_location not in sa_map:
            logging.warning(f"[AUDIT_EVENT] Skipping resource '{resource_name}' due to missing location '{resource_location}' in storage map")
            return {'status': 'skipped', 'reason': 'location_not_in_map'}

        storage_account_id = sa_map[resource_location]
        categories = {}

        if enable_aks_logs and resource_type == 'microsoft.containerservice/managedclusters':
            categories.update(cyngular_ds.AKS_SETTINGS)

        if enable_audit_events_logs:
            if resource_type in all_logs_types:
                categories.update(cyngular_ds.ALL_LOGS_SETTING)
            elif resource_type in all_logs_and_audit_types:
                categories.update(cyngular_ds.ALL_AND_AUDIT_LOG_SETTINGS)
            elif not categories:
                categories.update(cyngular_ds.AUDIT_EVENT_LOG_SETTINGS)

        if categories:
            diagnostic_settings = monitor_client.diagnostic_settings.list(resource_id)
            if not any(ds for ds in diagnostic_settings if all(
                log.category in categories and log.enabled for log in ds.logs
            )):
                create_diagnostic_settings(monitor_client, resource_id, storage_account_id, categories, cyngular_ds.CYNGULAR_DS_NAME, company_name)
                resource_subtype = resource_type.split('/')[-1] if '/' in resource_type else resource_type
                logging.warning(f"[AUDIT_EVENT] Created ds for resource '{resource_name}' | type {resource_subtype} | subscription '{subscription_id}'")
                return {'status': 'created', 'resource': resource_name}
        return {'status': 'unchanged', 'resource': resource_name}
    except Exception as e:
        logging.error(f"[AUDIT_EVENT] Error processing resource {resource.get('name', 'unknown')}: {str(e)}")
        return {'status': 'error', 'resource': resource.get('name', 'unknown'), 'error': str(e)}


def log_execution_time(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        function_name = func.__name__
        input_data = kwargs.get('input', {})
        subscription_id = input_data.get('subscription_id', 'unknown')
        subscription_name = input_data.get('subscription_name', subscription_id)

        start = time.time()
        try:
            result = func(*args, **kwargs)
            elapsed = time.time() - start

            logging.warning(f"[EXEC_TIME] Completed {function_name} in {elapsed:.2f} seconds || subscription: {subscription_name}")

            if isinstance(result, dict):
                result['execution_time_sec'] = elapsed
                result['function_name'] = function_name

            return result
        except Exception as e:
            elapsed = time.time() - start
            logging.critical(f"[EXEC_TIME] Failed {function_name} after {elapsed:.2f} seconds || subscription: {subscription_name} || error: {str(e)}")
            raise

    return wrapper
