import logging
import traceback
import os
import json

from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.monitor.models import DiagnosticSettingsResource
from azure.mgmt.network import NetworkManagementClient
from azure.mgmt.resource import ResourceManagementClient

from azure.mgmt.resourcegraph import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest, QueryRequestOptions, ResultFormat

import azure.functions as func
import azure.durable_functions as df

import ds_settings as cyngular_ds
import utils

try:
    on_boarding = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)
    logging.basicConfig(
        filename="onboarding.log", filemode="a", level=logging.warning,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    logging.info("[CONFIG] Configurations initialized")

    sa_map = json.loads(os.environ['STORAGE_ACCOUNT_MAP'])
    company_locations = json.loads(os.environ['COMPANY_LOCATIONS'])

    main_location = os.environ['COMPANY_MAIN_LOCATION']
    company_name = os.environ['COMPANY_NAME']

    enable_activity_logs = os.environ.get('enable_activity_logs', 'false').lower() == 'true'
    enable_audit_events_logs = os.environ.get('enable_audit_events_logs', 'false').lower() == 'true'
    enable_aks_logs = os.environ.get('enable_aks_logs', 'false').lower() == 'true'
    enable_flow_logs = os.environ.get('enable_flow_logs', 'false').lower() == 'true'

except Exception as e:
    logging.error(f"Err: {str(e)}")
    logging.critical(traceback.format_exc())
    raise Exception("Error parsing environment variables")

# Get credentials
try:
    credential = utils.get_client_credentials()
    logging.info("[CONFIG] Got client credentials")

except Exception as e:
    logging.error(f"Err: {str(e)}")
    logging.critical(traceback.format_exc())
    raise Exception("Error Initializing Credentials")


# """
# cyngulat trigger for Orchestration --  Durable Client Function -- Cron
# """
@on_boarding.durable_client_input(client_name="client")
@on_boarding.schedule(schedule="0 * * * *", arg_name="hourly_timer", run_on_startup=True)
async def durable_trigger_function_ds(hourly_timer: func.TimerRequest, client):
    try:
        if hourly_timer.past_due:
            logging.error("[CLIENT] Timer is past due")
            # return
        logging.warning("[CLIENT] Timer trigger started (hourly)")
        instance_id = await client.start_new("main_orchestrator")
        logging.warning(f"[CLIENT] Orchestration awaited with ID '{instance_id}'")
    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        raise Exception("Error starting orchestration")


################### ORCHESTRATION TRIGGERS ###############################

# """
# cyngular trigger for services --  Orchestration Function
# """
@on_boarding.orchestration_trigger(context_name="context")
def main_orchestrator(context: df.DurableOrchestrationContext):
    report = {
        "status": "init",
        "error": None,
        "sub_orchestrators": [],
        "main_orchestrator_time_sec": 0,
        "start_time": context.current_utc_datetime.isoformat(),
        "end_time": None
    }
    try:
        start = context.current_utc_datetime
        if not context.is_replaying:
            logging.warning("[MAIN_ORCHESTRATOR] Started ----------")

        subscriptions = utils.get_subscriptions(credential)
        if not context.is_replaying:
            logging.warning(f"[MAIN_ORCH] Found {len(subscriptions)} subscriptions")
        sub_tasks = [context.call_sub_orchestrator("subscription_sub_orchestrator",
            {
                "subscription_id": sub["subscription_id"],
                "subscription_name": sub["subscription_name"]
            }) for sub in subscriptions]

        yield context.task_all(sub_tasks)

        end_time = context.current_utc_datetime
        duration = (end_time - start).total_seconds()

        report.update({
            "status": "success",
            "sub_orchestrators": len(sub_tasks),
            "main_orchestrator_time_sec": duration,
            "end_time": end_time.isoformat()
        })

        if not context.is_replaying:
            logging.warning(f"[MAIN_ORCH] Completed with {len(sub_tasks)} sub-orchestrations ----------")

            logging.warning(f"[MAIN_ORCH] Completed Main Orchestrator Func || report: {report}")
        return report
    except Exception as e:
        duration = (context.current_utc_datetime - start).total_seconds()
        report.update({
            "status": "failed",
            "error": str(e),
            "main_orchestrator_time_sec": duration,
            "end_time": context.current_utc_datetime.isoformat()
        })
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        return report


###
# """
# cyngular trigger for Subscription --  Orchestration Function
# """
@on_boarding.orchestration_trigger(context_name="context")
def subscription_sub_orchestrator(context: df.DurableOrchestrationContext):
    orchestration_input = context.get_input()
    subscription_id = orchestration_input['subscription_id']
    subscription_name = orchestration_input['subscription_name']

    try:
        if not context.is_replaying:
            logging.warning(f"[SUBSCRIPTION_ORCH] Started -- subscription '{subscription_name}' == orch id: {context.instance_id}")
        if main_location not in sa_map:
            logging.error(f"[SUBSCRIPTION_ORCH] Primary location '{main_location}' not found in storage account mappings.")
            raise ValueError(f"[SUBSCRIPTION_ORCH] Primary location '{main_location}' not found in storage account mappings.")
        if not context.is_replaying:
            logging.info(f"[CYNGULAR][SUBSCRIPTION_ORCH] Using primary location '{main_location}'")

        if enable_activity_logs:
            yield context.call_activity("set_activity_logs_ds", {
                "subscription_id": subscription_id,
                "subscription_name": subscription_name,
                "storage_account_id": sa_map[main_location]
            })

        location_tasks = []
        for location in company_locations:
            location_tasks.append(context.call_sub_orchestrator("location_sub_orchestrator", {
                "subscription_id": subscription_id,
                "subscription_name": subscription_name,
                "location": location
            }))
        yield context.task_all(location_tasks)

    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        raise Exception(f"[SUBSCRIPTION_ORCH] An error occurred during the sub orchestration || subscription: {subscription_name}")

###
# """
# cyngular trigger for Location --  Orchestration Function
# """
@on_boarding.orchestration_trigger(context_name="context")
def location_sub_orchestrator(context: df.DurableOrchestrationContext):
    orchestration_input = context.get_input()
    subscription_id = orchestration_input['subscription_id']
    subscription_name = orchestration_input['subscription_name']
    location = orchestration_input['location']

    try:
        if not context.is_replaying:
            logging.warning(f"[LOCATION_ORCH] Started -- subscription '{subscription_name}' || location: {location} == orch id: {context.instance_id}")
        network_client = NetworkManagementClient(credential, subscription_id)
        resource_client = ResourceManagementClient(credential, subscription_id)
        logging.info("[CYNGULAR][LOCATION_ORCH] Initial clients created")
    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        raise Exception("Error getting initial clients")

    try:
        if enable_flow_logs:
            vnet_tasks = []
            logging.info(f"[CYNGULAR][LOCATION_ORCH] Processing NFL for subscription '{subscription_id}' in location '{location}'")
            network_watcher_rg = "NetworkWatcherRG"
            network_watcher_name = f"NetworkWatcher_{location}"
            try:
                network_watcher = utils.find_network_watcher(network_client, location)
                network_watcher_rg = network_watcher.id.split('/')[4]
                network_watcher_name = network_watcher.name
            except Exception as e:
                logging.error(f"Err: {str(e)}")
                logging.critical(traceback.format_exc())
                # raise Exception("Error getting Network Watcher")

            if not network_watcher:
                rg_name = "NetworkWatcherRG"
                nw_name = f"NetworkWatcher_{location}"

                try:
                    resource_client.resource_groups.get(rg_name)
                except Exception as e:
                    if Exception.__name__ == "ResourceNotFoundError":
                        try:
                            resource_client.resource_groups.create_or_update(rg_name, {"location": location})
                            logging.error(f"[LOCATION_ORCH] Created resource group '{rg_name}' in location '{location}'")
                        except Exception:
                            logging.error(f"[LOCATION_ORCH] Failed to create resource group '{rg_name}' in location '{location}'")
                    else:
                        ## attempt creation of rg ?
                        logging.error(f"Err: {str(e)}")
                        logging.critical(traceback.format_exc())

                network_watcher = network_client.network_watchers.create_or_update(
                    resource_group_name=rg_name,
                    network_watcher_name=nw_name,
                    parameters={"location": location}
                )
                network_watcher_rg = rg_name
                network_watcher_name = network_watcher.name
                logging.warning(f"[LOCATION_ORCH] Created Network Watcher in location '{location}' for subscription '{subscription_id}'")
                logging.info(f"[CYNGULAR][LOCATION_ORCH] Using Created Network Watcher '{network_watcher_name}' in resource group '{network_watcher_rg}'")
            else:
                logging.info(f"[CYNGULAR][LOCATION_ORCH] Using existing Network Watcher '{network_watcher_name}' in resource group '{network_watcher_rg}'")


            logging.info(f"[CYNGULAR][LOCATION_ORCH] Processing VNet Flow Logs for subscription '{subscription_id}' || location '{location}'")
            vnets_info = list(network_client.virtual_networks.list_all())
            vnets = [
                {"id": vnet.id, "name": vnet.name, "location": vnet.location}
                for vnet in vnets_info if vnet.location.lower() == location.lower()
            ]
            vnet_tasks = [
                context.call_activity("set_vnet_flow_logs", {
                    "subscription_id": subscription_id,
                    "network_watcher_rg": network_watcher_rg,
                    "network_watcher_name": network_watcher_name,
                    "location": location,
                    "vnet": vnet
                }) for vnet in vnets
            ]
            yield context.task_all(vnet_tasks)

        resources = yield context.call_activity("query_resources", {
            "subscription_id": subscription_id,
            "whitelisted_types": cyngular_ds.whitelisted_types,
            "location": location
        })

        all_logs_types = [rtype.lower() for rtype in cyngular_ds.all_logs_types]
        all_logs_and_audit_types = [rtype.lower() for rtype in cyngular_ds.all_logs_and_audit_types]

        if not resources:
            logging.info(f"[CYNGULAR][AUDIT_EVENT] No resources found in subscription: {subscription_id} || location: {location}")
            return
        audit_event_tasks = [context.call_activity("set_audit_event_ds", {
            "subscription_id": subscription_id,
            "resource": resource,
            "all_logs_types": all_logs_types,
            "all_logs_and_audit_types": all_logs_and_audit_types
        }) for resource in resources]

        yield context.task_all(audit_event_tasks)
        logging.info(f"[CYNGULAR][LOCATION_ORCH] Completed Orchestration for sub -< {subscription_name} >- || location: {location}")

    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        raise Exception(f"[LOCATION_ORCH] An error occurred during the location orchestration || subscription: {subscription_name} || location: {location}")


##################### ACTIVITIES TRIGGERS ###############################

# """
# cyngular services --  Activity Function -- Set Activity Logs
# """
@on_boarding.activity_trigger(input_name="input")
@utils.log_execution_time
def set_activity_logs_ds(input):
    subscription_id = input["subscription_id"]
    subscription_name = input["subscription_name"]
    storage_account_id = input["storage_account_id"]

    try:
        monitor_client = MonitorManagementClient(credential, subscription_id)
        existing_settings = monitor_client.diagnostic_settings.list(
            resource_uri=f"/subscriptions/{subscription_id}"
        )
        # generator expression, find first ds matching the given storage_account_id. If none are found, defaults to None.
        setting_name = next(
            (setting.name for setting in existing_settings if setting.storage_account_id == storage_account_id),
            None
        )
        operation = "update" if setting_name else "create"

        parameters = DiagnosticSettingsResource(
            storage_account_id=storage_account_id,
            logs=[{"category": category, "enabled": True} for category in cyngular_ds.ACTIVITY_LOG_SETTINGS]
        )

        monitor_client.diagnostic_settings.create_or_update(
            resource_uri=f"/subscriptions/{subscription_id}",
            name=setting_name or f"{cyngular_ds.CYNGULAR_DS_NAME}-{company_name}",
            parameters=parameters
        )
        logging.warning(f"[ACTIVITY_LOGS] {operation.capitalize()}d for subscription '{subscription_name}' [{subscription_id}]")
        return {"status": "success"}
    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        return {"status": "failed"}


###

# """
# cyngular services --  Activity Function -- Set Audit Event Logs
# """
@on_boarding.activity_trigger(input_name="input")
@utils.log_execution_time
def set_audit_event_ds(input):
    subscription_id = input["subscription_id"]
    resource = input["resource"]
    all_logs_types = input["all_logs_types"]
    all_logs_and_audit_types = input["all_logs_and_audit_types"]

    try:
        monitor_client = MonitorManagementClient(credential, subscription_id)
        resource_name = resource.get('name', 'unknown')
        logging.warning(f"[AUDIT_EVENT] Processing resource '{resource_name}' for subscription '{subscription_id}'")

        result = utils.process_resource_for_ds(
            resource=resource,
            monitor_client=monitor_client,
            sa_map=sa_map,
            company_name=company_name,
            enable_audit_events_logs=enable_audit_events_logs,
            enable_aks_logs=enable_aks_logs,
            all_logs_types=all_logs_types,
            all_logs_and_audit_types=all_logs_and_audit_types,
            subscription_id=subscription_id
        )

        return {
            "status": "success" if result['status'] in ('created', 'unchanged', 'skipped') else "failed",
            "result": result['status'],
            "resource": result.get('resource', resource_name)
        }
    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        return {"status": "failed"}


###
# """
# cyngular services --  Activity Function -- Query Resources
# """
@on_boarding.activity_trigger(input_name="input")
@utils.log_execution_time
def query_resources(input):
    subscription_id   = input["subscription_id"]
    location         = input["location"]
    whitelisted_types = input["whitelisted_types"]

    try:
        resource_graph_client = ResourceGraphClient(credential)
        whitelist = ", ".join(f"'{rt.lower()}'" for rt in whitelisted_types)
        # locations = ", ".join(f"'{loc}'" for loc in locations)

        if len(whitelisted_types) == 1:
            type_filter = f"type == '{whitelisted_types[0].lower()}'"
        else:
            whitelist = ", ".join(f"'{rt.lower()}'" for rt in whitelisted_types)
            type_filter = f"type in ({whitelist})"

        query = f"""
        resources
        | where {type_filter}
        | where location == '{location}'
        | project id, name, type, location, resourceGroup
        """

        # | where location in ({locations_str})

        # query = f"""
        # resources
        # | where type in ({whitelist})
        # | where location == '{location}'
        # | project id, name, type, location, resourceGroup
        # """

        logging.warning(f"[RESOURCES] Querying subscription '{subscription_id}'")
        options = QueryRequestOptions(result_format=ResultFormat.object_array)
        request = QueryRequest(
            query=query,
            subscriptions=[subscription_id],
            options=options
        )
        response = resource_graph_client.resources(request)

        if response.count == 0:
            logging.info(f"[RESOURCES] No resources found in subscription: {subscription_id} || location: {location}")
            return []

        logging.info(f"[RESOURCES] Found {response.count} resources in subscription '{subscription_id}'")
        return response.data

    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        return []


###
# """
# cyngular services --  Activity Function -- Set VNet Flow Logs
# """
@on_boarding.activity_trigger(input_name="input")
@utils.log_execution_time
def set_vnet_flow_logs(input):
    subscription_id = input["subscription_id"]
    location = input["location"]
    network_watcher_rg = input["network_watcher_rg"]
    network_watcher_name = input["network_watcher_name"]
    vnet = input["vnet"]
    storage_account_id = sa_map[location]

    try:
        logging.warning(f"[VNET_FLOW] Checking flow logs for VNet '{vnet['name']}'")
        network_client = NetworkManagementClient(credential, subscription_id)

        flow_logs = list(network_client.flow_logs.list(
            resource_group_name=network_watcher_rg,
            network_watcher_name=network_watcher_name
        ))
        existing_log = next((log for log in flow_logs if log.target_resource_id == vnet["id"]), None)

        if existing_log:
            logging.info(f"[VNET_FLOW] Flow log already exists for VNet '{vnet['name']}', skipping creation/update.")
            return

        vnet_flow_log_name = f"{vnet['name']}-FlowLog"
        poller = network_client.flow_logs.begin_create_or_update(
            resource_group_name=network_watcher_rg,
            network_watcher_name=network_watcher_name,
            flow_log_name=vnet_flow_log_name,
            parameters={
                "enabled": True,
                "location": location,
                "targetResourceId": vnet["id"],
                "storageId": storage_account_id,
                "retentionPolicy": {
                    "days": 0,
                    "enabled": False
                },
                "format": {
                    "type": "JSON",
                    "version": 2
                }
            }
        )
        result = poller.result()
        logging.warning(f"[VNET_FLOW] Created flow log for VNet '{vnet['name']}' | location: '{location}'")
        logging.info(f"[CYNGULAR][VNET_FLOW] Result: {result}")
    except Exception as e:
        logging.error(f"Err: {str(e)}")
        logging.critical(traceback.format_exc())
        raise Exception(f"Failed to set VNet flow logs for subscription: {subscription_id} | Location: {location}. Error: {str(e)}")
